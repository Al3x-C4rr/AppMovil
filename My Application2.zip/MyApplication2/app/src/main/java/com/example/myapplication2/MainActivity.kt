package com.example.myapplication2

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import androidx.compose.ui.layout.ContentScale
import com.example.myapplication2.ui.theme.MyApplication2Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplication2Theme {
                EditorScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen() {
    Scaffold(
        topBar = {
            TopAppBar(title = { Text("AudioCraft") })
        },
        bottomBar = { BottomMenu() }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            ControlsRow()
            ItemCard(
                title = "Proyecto",
                imageUrl = "https://picsum.photos/600/300"
            )
            TrackItem("Drums")
            TrackItem("Bass")
            TrackItem("Synth")
        }
    }
}

@Composable
fun ControlsRow() {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        listOf("◀","▶","■","♫").forEach {
            ElevatedCard {
                Box(
                    Modifier.size(48.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(it)
                }
            }
        }
    }
}

@Composable
fun ItemCard(title:String,imageUrl:String){
    ElevatedCard(
        modifier=Modifier.fillMaxWidth()
    ){
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)){
            Text(title, style = MaterialTheme.typography.titleLarge)
            AsyncImage(
                model=imageUrl,
                contentDescription=title,
                modifier=Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .clip(RoundedCornerShape(12.dp)),
                contentScale=ContentScale.Crop
            )
        }
    }
}

@Composable
fun TrackItem(name:String){
    ElevatedCard(modifier=Modifier.fillMaxWidth()){
        Row(
            Modifier.padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ){
            Text(name, modifier=Modifier.width(70.dp))
            Box(
                Modifier
                    .height(40.dp)
                    .weight(1f)
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.primary,
                        RoundedCornerShape(8.dp)
                    )
            )
        }
    }
}

@Composable
fun BottomMenu(){
    NavigationBar {
        NavigationBarItem(selected=true,onClick={},icon={},label={Text("Editor")})
        NavigationBarItem(selected=false,onClick={},icon={},label={Text("Biblioteca")})
        NavigationBarItem(selected=false,onClick={},icon={},label={Text("Perfil")})
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewEditor(){
    MyApplication2Theme {
        EditorScreen()
    }
}
